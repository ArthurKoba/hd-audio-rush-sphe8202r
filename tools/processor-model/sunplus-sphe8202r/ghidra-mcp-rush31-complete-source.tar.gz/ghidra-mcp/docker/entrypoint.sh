#!/bin/bash
# GhidraMCP Headless Server Entrypoint Script

set -e

# Configuration from environment variables
PORT=${GHIDRA_MCP_PORT:-8089}
BIND_ADDRESS=${GHIDRA_MCP_BIND_ADDRESS:-"0.0.0.0"}  # Default to all interfaces for Docker
JAVA_OPTS=${JAVA_OPTS:-"-Xmx4g -XX:+UseG1GC"}
GHIDRA_USER=${GHIDRA_USER:-""}  # Set to project owner name to bypass ownership checks

# Shared Ghidra server configuration
GHIDRA_SERVER_HOST=${GHIDRA_SERVER_HOST:-""}
GHIDRA_SERVER_PORT=${GHIDRA_SERVER_PORT:-""}
GHIDRA_SERVER_USER=${GHIDRA_SERVER_USER:-""}

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  GhidraMCP Headless Server${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# Print configuration
echo -e "${YELLOW}Configuration:${NC}"
echo "  Bind Address: ${BIND_ADDRESS}"
echo "  Port: ${PORT}"
echo "  Java Options: ${JAVA_OPTS}"
echo "  Ghidra Home: ${GHIDRA_HOME}"
if [ -n "${GHIDRA_USER}" ]; then
    echo "  Ghidra User: ${GHIDRA_USER}"
fi
if [ -n "${GHIDRA_SERVER_HOST}" ]; then
    echo "  Server Host: ${GHIDRA_SERVER_HOST}"
    echo "  Server Port: ${GHIDRA_SERVER_PORT:-13100}"
fi
if [ -n "${GHIDRA_SERVER_USER}" ]; then
    echo "  Server User: ${GHIDRA_SERVER_USER}"
fi
echo ""

# Check Ghidra installation
if [ ! -d "${GHIDRA_HOME}" ]; then
    echo -e "${RED}Error: Ghidra not found at ${GHIDRA_HOME}${NC}"
    exit 1
fi

# Build classpath with Ghidra JARs
CLASSPATH="/app/GhidraMCP.jar"

# Add Ghidra Framework JARs
for jar in ${GHIDRA_HOME}/Ghidra/Framework/*/lib/*.jar; do
    CLASSPATH="${CLASSPATH}:${jar}"
done

# Add Ghidra Feature JARs
for jar in ${GHIDRA_HOME}/Ghidra/Features/*/lib/*.jar; do
    CLASSPATH="${CLASSPATH}:${jar}"
done

# Add Ghidra Processor JARs
for jar in ${GHIDRA_HOME}/Ghidra/Processors/*/lib/*.jar; do
    CLASSPATH="${CLASSPATH}:${jar}"
done

# Add application lib JARs
if [ -d "/app/lib" ]; then
    for jar in /app/lib/*.jar; do
        [ -f "$jar" ] && CLASSPATH="${CLASSPATH}:${jar}"
    done
fi

# Worker pool configuration
WORKER_COUNT=${GHIDRA_MCP_WORKER_COUNT:-1}
WORKER_JAVA_OPTS=${GHIDRA_MCP_WORKER_JAVA_OPTS:-${JAVA_OPTS}}
WORKER_CONTROL_FIFO=${GHIDRA_MCP_WORKER_CONTROL_FIFO:-/data/bridge/worker-control.fifo}
WORKER_PID_DIR=${GHIDRA_MCP_WORKER_PID_DIR:-/data/bridge/workers}
SUPERVISOR_MAIN_PID="${BASHPID}"

if ! [[ "${WORKER_COUNT}" =~ ^[1-9][0-9]*$ ]]; then
    echo -e "${RED}Error: GHIDRA_MCP_WORKER_COUNT must be a positive integer${NC}"
    exit 1
fi

# Build user.name option if GHIDRA_USER is set
USER_OPT=""
if [ -n "${GHIDRA_USER}" ]; then
    USER_OPT="-Duser.name=${GHIDRA_USER}"
fi

EXTRA_ARGS=()
if [ "$#" -gt 0 ]; then
    EXTRA_ARGS=("$@")
fi
if [ -n "${PROGRAM_FILE:-}" ] && [ -f "${PROGRAM_FILE}" ]; then
    EXTRA_ARGS+=("--file" "${PROGRAM_FILE}")
fi
if [ -n "${PROJECT_PATH:-}" ] && [ -e "${PROJECT_PATH}" ]; then
    if [ "${WORKER_COUNT}" -gt 1 ]; then
        echo -e "${RED}Error: PROJECT_PATH is incompatible with a multi-worker pool; use project_id routing instead.${NC}"
        exit 1
    fi
    EXTRA_ARGS+=("--project" "${PROJECT_PATH}")
fi

echo -e "${YELLOW}Worker pool:${NC}"
echo "  Workers: ${WORKER_COUNT}"
echo "  Base Port: ${PORT}"
echo "  Worker Java Options: ${WORKER_JAVA_OPTS}"
echo ""

start_worker() {
    local index="$1"
    local worker_port=$((PORT + index))
    local worker_home="/data/workers/worker-${index}/home"
    local worker_cache="/tmp/ghidra-script-cache/worker-${index}"

    mkdir -p "${worker_home}" "${worker_cache}"

    local heap_file="${WORKER_PID_DIR}/worker-${index}.heap-mb"
    local -a java_args=()
    read -r -a java_args <<< "${WORKER_JAVA_OPTS}"
    if [ -f "${heap_file}" ]; then
        local heap_mb
        heap_mb=$(cat "${heap_file}")
        if [[ "${heap_mb}" =~ ^[0-9]+$ ]] && (( heap_mb >= 128 && heap_mb <= 32768 )); then
            local -a filtered=()
            local option
            for option in "${java_args[@]}"; do
                [[ "${option}" == -Xmx* ]] || filtered+=("${option}")
            done
            java_args=("${filtered[@]}" "-Xmx${heap_mb}m")
        fi
    fi

    echo -e "${GREEN}Starting worker ${index} on port ${worker_port}...${NC}"
    HOME="${worker_home}" \
    GHIDRA_MCP_SCRIPT_CACHE="${worker_cache}" \
    java \
        "${java_args[@]}" \
        ${USER_OPT} \
        -Duser.home="${worker_home}" \
        -Dghidra.home="${GHIDRA_HOME}" \
        -Dapplication.name="GhidraMCP-worker-${index}" \
        -classpath "${CLASSPATH}" \
        com.xebyte.headless.GhidraMCPHeadlessServer \
        --port "${worker_port}" \
        --bind "${BIND_ADDRESS}" \
        "${EXTRA_ARGS[@]}" &
    PIDS["${index}"]="$!"
    mkdir -p "${WORKER_PID_DIR}"
    printf '%s\n' "${PIDS[$index]}" > "${WORKER_PID_DIR}/worker-${index}.pid"
}

if [ "${WORKER_COUNT}" -eq 1 ]; then
    worker_home="/data/workers/worker-0/home"
    worker_cache="/tmp/ghidra-script-cache/worker-0"
    mkdir -p "${worker_home}" "${worker_cache}"
    echo -e "${GREEN}Starting single Ghidra worker...${NC}"
    exec env HOME="${worker_home}" GHIDRA_MCP_SCRIPT_CACHE="${worker_cache}" \
        java \
        ${WORKER_JAVA_OPTS} \
        ${USER_OPT} \
        -Duser.home="${worker_home}" \
        -Dghidra.home="${GHIDRA_HOME}" \
        -Dapplication.name="GhidraMCP-worker-0" \
        -classpath "${CLASSPATH}" \
        com.xebyte.headless.GhidraMCPHeadlessServer \
        --port "${PORT}" \
        --bind "${BIND_ADDRESS}" \
        "${EXTRA_ARGS[@]}"
fi

PIDS=()
SHUTTING_DOWN=0
CONTROL_PID=""

setup_worker_control() {
    mkdir -p "$(dirname "${WORKER_CONTROL_FIFO}")" "${WORKER_PID_DIR}"
    rm -f "${WORKER_CONTROL_FIFO}"
    mkfifo "${WORKER_CONTROL_FIFO}"
    chmod 660 "${WORKER_CONTROL_FIFO}"
}

worker_control_loop() {
    # Keep one read/write fd open for the lifetime of the supervisor so a
    # non-blocking bridge writer never races a FIFO close/reopen window.
    exec 9<>"${WORKER_CONTROL_FIFO}"
    while [ "${SHUTTING_DOWN}" -eq 0 ]; do
        local action=""
        local index=""
        local value=""
        if ! read -r action index value <&9; then
            continue
        fi
        if ! [[ "${index}" =~ ^[0-9]+$ ]] || [ "${index}" -ge "${WORKER_COUNT}" ]; then
            echo "Ignoring invalid worker index: ${index}"
            continue
        fi
        local stopped_file="${WORKER_PID_DIR}/worker-${index}.stopped"
        if [ "${action}" = "stop" ]; then
            : > "${stopped_file}"
        elif [ "${action}" = "start" ]; then
            rm -f "${stopped_file}"
            kill -USR1 "${SUPERVISOR_MAIN_PID}" 2>/dev/null || true
            continue
        elif [ "${action}" = "restart" ]; then
            rm -f "${stopped_file}"
            kill -USR1 "${SUPERVISOR_MAIN_PID}" 2>/dev/null || true
        elif [ "${action}" = "heap" ]; then
            if ! [[ "${value}" =~ ^[0-9]+$ ]] || (( value < 128 || value > 32768 )); then
                echo "Ignoring invalid worker heap: ${value}"
                continue
            fi
            local heap_file="${WORKER_PID_DIR}/worker-${index}.heap-mb"
            local temp_file="${heap_file}.tmp.${BASHPID}"
            printf '%s\n' "${value}" > "${temp_file}"
            mv -f "${temp_file}" "${heap_file}"
        else
            echo -e "${YELLOW}Ignoring invalid worker control command: ${action} ${index}${NC}"
            continue
        fi
        local pid_file="${WORKER_PID_DIR}/worker-${index}.pid"
        local pid=""
        if [ -r "${pid_file}" ]; then
            pid=$(cat "${pid_file}" 2>/dev/null || true)
        fi
        if [ -n "${pid}" ] && kill -0 "${pid}" 2>/dev/null; then
            echo -e "${YELLOW}Emergency-restarting worker ${index} (pid ${pid})...${NC}"
            kill -KILL "${pid}" 2>/dev/null || true
        else
            echo -e "${YELLOW}Worker ${index} has no live pid; supervisor will reconcile on exit.${NC}"
        fi
    done
    exec 9>&-
}

cleanup() {
    if [ "${SHUTTING_DOWN}" -eq 1 ]; then
        return
    fi
    SHUTTING_DOWN=1
    trap - SIGTERM SIGINT EXIT
    echo ""
    echo -e "${YELLOW}Shutting down GhidraMCP worker pool...${NC}"
    if [ -n "${CONTROL_PID}" ]; then
        kill "${CONTROL_PID}" 2>/dev/null || true
    fi
    if [ "${#PIDS[@]}" -gt 0 ]; then
        kill "${PIDS[@]}" 2>/dev/null || true
        wait "${PIDS[@]}" 2>/dev/null || true
    fi
    rm -f "${WORKER_CONTROL_FIFO}"
}

trap 'cleanup; exit 0' SIGTERM SIGINT
trap ':' SIGUSR1
trap cleanup EXIT

setup_worker_control
worker_control_loop &
CONTROL_PID="$!"

for ((i=0; i<WORKER_COUNT; i++)); do
    if [ -f "${WORKER_PID_DIR}/worker-${i}.stopped" ]; then
        PIDS["${i}"]=""
    else
        start_worker "${i}"
    fi
done

# Supervise each worker independently. A clean /exit_ghidra request or a crash
# restarts only that JVM; other project sessions remain available.
while [ "${SHUTTING_DOWN}" -eq 0 ]; do
    # Empty slots represent deliberately stopped JVMs; never wait on them.
    WAIT_PIDS=()
    for pid in "${PIDS[@]}"; do
        [ -z "${pid}" ] || WAIT_PIDS+=("${pid}")
    done
    if [ "${#WAIT_PIDS[@]}" -eq 0 ]; then
        sleep 0.2
    fi
    EXITED_PID=""
    set +e
    if [ "${#WAIT_PIDS[@]}" -gt 0 ]; then
        wait -n -p EXITED_PID "${WAIT_PIDS[@]}"
    fi
    STATUS=$?
    set -e
    if [ "${SHUTTING_DOWN}" -eq 1 ]; then
        break
    fi

    EXITED_INDEX=""
    for ((i=0; i<WORKER_COUNT; i++)); do
        if [ "${PIDS[$i]:-}" = "${EXITED_PID}" ]; then
            EXITED_INDEX="${i}"
            break
        fi
    done
    if [ -n "${EXITED_INDEX}" ]; then
        PIDS["${EXITED_INDEX}"]=""
        rm -f "${WORKER_PID_DIR}/worker-${EXITED_INDEX}.pid"
        if [ -f "${WORKER_PID_DIR}/worker-${EXITED_INDEX}.stopped" ]; then
            echo "Worker ${EXITED_INDEX} stopped (status ${STATUS}); keeping it stopped."
        else
            echo "Worker ${EXITED_INDEX} exited (status ${STATUS}); restarting it."
        fi
    fi
    # Wakeups from the control FIFO can interrupt wait -n with no exited PID.
    # Also restart explicitly re-enabled slots with no running JVM.
    for ((i=0; i<WORKER_COUNT; i++)); do
        if [ -z "${PIDS[$i]:-}" ] && [ ! -f "${WORKER_PID_DIR}/worker-${i}.stopped" ]; then
            start_worker "${i}"
        fi
    done
done
