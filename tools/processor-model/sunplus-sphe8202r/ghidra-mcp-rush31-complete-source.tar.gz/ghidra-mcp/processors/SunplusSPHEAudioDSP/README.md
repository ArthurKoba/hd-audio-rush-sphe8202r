# Sunplus SPHE audio DSP processor module

Experimental Ghidra SLEIGH language support for the 24-bit audio-DSP program
images used by the Sunplus SPHE8202R family.

The target instruction encoding is ADSP-218x-compatible for the instruction
forms currently implemented here. The module is intentionally named for the
Sunplus target rather than claiming complete ADSP-218x compatibility: the
Sunplus integration and data-memory behavior still contain target-specific
unknowns.

## Opt-in native software sequencer: shared stack and RTI (local acceptance)

`sunplus_stack_runtime.sinc` and `sunplus_stack_instructions.sinc` implement
`codec_arch_stack_mode=1` as a separate, executable SLEIGH view. The accepted
legacy C-analysis view (`codec_arch_stack_mode=0`) remains unchanged.
The software sequencer implements a shared **16-entry PC stack** for `CALL`,
`RTS` and `DO`, four nested-loop frames, four preserved counter frames,
12 status frames, `RTI` return/status restoration, ASTAT flags, MSTAT
secondary register banks, condition-code selection, delayed TOPPCSTACK pop,
and explicit faults for invalid stack state. No firmware PM or DM bytes are
rewritten; the additional `DSPSTACK` space stores analysis-time sequencer state.

The saved local `SunplusArchitecturalStackAcceptance.java` readback passed
**40,017 checks**, **72,791 real-instruction P-code executions**, and nine
specific fault controls. The composed SLEIGH language compiled reproducibly;
all five saved firmware profiles retained **462/462 Analyzer C, 426/426 CE,
zero C warnings**, with **28,326/28,326 freshly decoded instructions**
matching saved text and normalized P-code. All C files kept identical content.
The isolated Ghidra worker exited cleanly after save/reopen. The machine
execution checks use an explicit local fault userop implementation and do
not claim asynchronous interrupt scheduling, complete hardware equivalence,
or readiness to migrate to the canonical Analyzer. The opt-in mode has been
verified as a reusable software instruction model, not silently enabled for
existing firmware.

## I/M/L circular-address candidate (RUSH 25 local acceptance)

The SLEIGH source now routes **all 86 index post-updates** through one shared
signed-14-bit `M` / zero-disabled `L` modulo computation, selecting the matching
`L0..L7` by the **I register**, not the M register. The linear `L=0` path
retains the previous full 16-bit index arithmetic. Indirect DAG1 memory access
still applies the separate conditional 14-bit bit-reversal on the *current*
index, not on its post-update; DAG2 does not reverse the address. PM24 and
DM16 remain distinct. Documented modulo preconditions require a valid index
inside its inferred circular window and modifier magnitude smaller than the
window; invalid/out-of-range states and silicon timing are **UNKNOWN**.

Local Ghidra 12.1.3 acceptance: 13/13 EmulatorHelper cases, 7/7 synthetic C,
then 460/460 saved native functions across five isolated codec/wrapper projects,
with save/close/reopen/readback. C warning owners stayed at 42 (AC-3 22,
PCM 12, AUX 8, DTS and wrapper 0). This is static/P-code acceptance, not
complete processor or target-board behavior. The canonical Analysis project
was not modified.

## Current scope

The module has moved beyond the original decode-smoke stage. Its validated scope now includes the complete local instruction corpus used by the canonical SPHE8202R `srvdsp.bin` wrapper plus every instruction word reached by vector-seeded native control flow in the extracted AUX, PCM, AC-3 and DTS codec profiles used for this target. This is reachable-code coverage, not a claim that every 24-bit word in each profile is executable code or that the entire ADSP-218x ISA is implemented.

Architecture/model contract:

- fixed 24-bit big-endian instruction words;
- PM is word-addressed with `wordsize=3` and required `alignment=3`;
- 16-bit DM and IO address spaces;
- explicit PM / DM / IO separation;
- compiler/decompiler model with a synthetic `SP` only for ABI/decompiler support;
- direct and conditional PM flow;
- explicit resident-PM handoffs that preserve the numeric target without fabricating unavailable resident code, enabled only under canonical `srvdsp` wrapper context;
- `CNTR`-controlled P-code for the proven wrapper `DO PM:186C UNTIL CE` and bounded codec CE-loop nesting, verified by independent 2-level and 4-level P-code emulation fixtures; the native PCM PM:12B9..12BD single-loop regression remains.

Instruction families exercised and modeled by the canonical corpus:

- type 3 — direct DM read/write;
- type 4 — ALU/MAC + DM access forms used by the wrapper;
- type 6 — immediate data-register load;
- type 7 — immediate non-data-register load;
- type 9 — arithmetic/logic forms used by the wrapper;
- type 10 — conditional/unconditional flow and call/jump forms used by the wrapper;
- type 11 — zero-overhead `DO ... UNTIL CE` setup for the proven corpus sequence;
- type 15 — immediate shifter form used by the corpus;
- type 17 — internal register move;
- type 20 — RTS plus codec-observed RTI, with RTI status restoration kept distinct through an explicit userop until the architectural status stack is modeled;
- type 29 — IO-space write form used by the wrapper.

The codec-profile extension now covers the reachable arithmetic/MAC, parallel data/PM/DM access, shifter, stack/mode, direct/indirect flow and internal-register forms exercised by the four extracted decoder profiles. Wrapper-only resident handoffs remain context-scoped. `NEG`/`POS` use the architectural AS input-sign state produced by ABS rather than being approximated through the ALU result-negative flag.

The module remains intentionally named for the Sunplus target. It is **corpus-complete for the recovered SPHE wrapper and zero-gap for the currently reachable control-flow corpus of the four extracted codec profiles**, not a claim that the full ADSP-218x ISA, every word in the profile images, or every Sunplus DSP peripheral semantic is implemented.

The first target regression words remain useful smoke vectors:

| Word | Expected decode |
| --- | --- |
| 0x19820f | JUMP 0x1820 |
| 0x0a000f | RTS |
| 0x80023a | direct DM read into AR from 0x0023 |
| 0x80021a | direct DM read into AR from 0x0021 |
| 0x0a001f | RTI |
| 0x180250 | IF EQ JUMP 0x0025 |
| 0x22e21f | AR = AR - 1 |
| 0x0f02f6 | SR = LSHIFT AR BY -10 (HI) |
| 0x0d00af | AR = SR1 |
| 0x18036f | generic JUMP 0x0036 when wrapper context is not enabled |

## Production validation — 2026-10-02

The completed target-corpus extension is present in `ghidra-mcp/main` commit `5570d8c623ee72e2be9f07eb271d1127fb7d297f` and was deployed to the production Analysis backend through Coolify deployment `#296` on 2026-10-02.

Post-deploy checks:
- production Analysis decoded the previously incomplete AUX entry range with the extended instruction set active;
- canonical `srvdsp.bin` remained at 117/117 local executable words, 9/9 action nodes and 9/9 high-level behavior views;
- the saved board project was re-audited after deployment and retained 21/21 named, typed and documented DM state/config slots;
- AUX/PCM/AC-3/DTS reachable-code acceptance remains zero-gap at 5451/5451, 7787/7787, 10339/10339 and 9651/9651 reached words respectively.

This validates the deployed processor/runtime path for the current target corpus. It does not upgrade corpus coverage into full ADSP-218x compatibility or prove Sunplus DSP clock, cycle budget, memory capacity, peripheral mapping or physical audio-lane ownership.

Board-specific continuation evidence and the current AP1/runtime audio-control contract live in `ArthurKoba/hd-audio-rush-sphe8202r`; keep reusable processor semantics here and target behavior findings in the board repository.

## 24-bit PM C-decompiler recovery (local candidate, 2026-10-09)

A native Ghidra 12.1.3 decompiler regression affected five DTS functions
(`PM:1769`, `25B7`, `266B`, `273E`, `2755`). All five timed out under
full `decompile` even with a longer budget; the `firstpass`, `register` and
`normalize` stages returned promptly. The failure reproduces in standalone
headless Ghidra without MCP, and persists after mapping the missing DM region.

Target-byte ablations establish that removing dynamic PM reads or DM/PM writes
breaks the timeout. Using 16-bit PM loads/stores also unblocks all five, but
**silently drops eight bits and is not a valid DSP model**. The model therefore
keeps PM as a 24-bit word-addressed space. The initial 2026-10-09 fix
represented *pure Type-5* program-memory accesses with
`dsp_pm_load24(address)` and `dsp_pm_store24(address,word)` p-code userops.
The 2026-10-13 local follow-up extended the same width-preserving interface
to the remaining Type-3 / combined Type-5 ALU/MAC/PM forms: eight combined
PM reads, fourteen additional PM reads and four additional PM stores. The word address remains
16-bit; the read result and write value are full 24-bit words. `DReg4` receives
bits 23..8 and `PX` receives bits 7..0, unchanged from the original encoding.
These operations remain visible in generated C instead of producing a
truncated or invented C translation.

**Local Ghidra 12.1.3 verification** (isolated SDK/project, not production):
SLEIGH compiles; P-code inspection verified 3-byte read/output and write/input
with 2-byte word addresses. From the saved canonical function-entry inventory,
the historical partial-function sample yielded DTS 98/98, AUX 61/61,
PCM 4/4 and AC-3 25/25; srvdsp passed 117/117 code words and 9/9 C.
These historical sample counts are **not** the complete saved corpus.
`ghidra_scripts/SunplusDSPFullCorpusAcceptance.java` supersedes the removed
partial-corpus acceptance and audits the exact saved function inventory,
CE P-code backedges, CFG ownership, C output and semantic warnings.

**Validation boundary:** `CALL_OTHER` is an *opaque representation* for the
native Ghidra decompiler. Its declared arguments and values preserve the full
24-bit PM access interface, but the userops do **not yet implement PM backing
memory side effects for P-code emulation** and do not model read-after-write
aliasing internally. An emulator/userop library or an upstream decompiler fix
is required before claiming native execution-equivalent P-code. Separately,
the existing canonical Analysis project must refresh saved instruction P-code
under a deployed language model before its old C views can be counted as
repaired. This is local static-C validation, not deployed/runtime/hardware
acceptance or full DSP-algorithm recovery.

## Full 24-bit PM access audit — isolated local candidate, 2026-10-13

The earlier Type-5-only userop mapping left twenty-six direct 24-bit
program-memory accesses in combined DSP instruction constructors. Two
fully decoded AUX functions (`PM:1306` and `PM:1400`) acquired the correct
native CE `CBRANCH` but the Ghidra 12.1.3 full-C optimizer timed out.
Replacing only eight combined PM reads did **not** eliminate the timeout.
An isolated build using the same 16-bit PM word address and full 24-bit
`dsp_pm_load24`/`dsp_pm_store24` interface for all twenty-six remaining
accesses completed both cases. Recovered AUX CE coverage on the preserved,
independently reopened local GZF progressed to **55/55**, with **68/68**
identified AUX functions decompiling successfully. The 68-function inventory
includes two new *provisional* entries backed by structural control-flow
and/or direct CALL evidence; it must not be treated as proof of complete
reachability or algorithm recovery.

**Local userop execution proof:** `ghidra_scripts/SunplusPm24UseropExecutionAcceptance.java`
implements a concrete `AnnotatedPcodeUseropLibrary<byte[]>` for an isolated
`PcodeEmulator`. Its native Ghidra 12.1.3 regression executed two 24-bit PM
reads and three 24-bit PM writes, confirmed 3-byte word-addressing and verified
read-after-write aliasing. This library is **not automatically registered for
production Analysis emulators**; users must explicitly supply the library to
a Ghidra P-code emulator. The static decompiler userop call cannot implement
backing PM by itself.

**Nested Type17 counter move:** the 2026-10-13 isolated native AC-3
`PM:0B7A` regression validated an opt-in depth-2 `CNTR = AR` Type17
constructor: it saves the outer counter in `DSP_STATIC_CNTR_OUTER` before the
inner loop, allowing the inner CE end to restore it. This recovered two native
CE backedges and two additional C loops without new warnings, confirmed by
reopening the saved local GZF. AC-3 `PM:041E` recovered its standalone
CE at `PM:0422/0423`; its *two nested* CE loops remain unresolved in C,
and must not be counted as accepted. Neither experiment proves every nested
pattern or physical DSP execution equivalence.

**Nested inner direct CE (local proof):** a separately opted-in
`codec_ce_static_depth=2` direct CE constructor now provides a statically
verified backedge for the inner `DO`, restores `DSP_STATIC_CNTR_OUTER` only
when the inner count expires, and requires the native Type17 `CNTR = AR`
constructor to save the outer count first. The isolated AC-3 `PM:1051`
experiment restored its two nested pairs (4 new C loops; 17→21, 30 warnings
unchanged). A separate read-only reopen of the saved 160-function AC-3 GZF
reported CE 150/166→154/166, C 160/160, no new decompiler warning functions;
both native counter-move sites emitted the extra saved-counter P-code copy.
A separate synthetic 2×3 nested CE `PcodeEmulator` test for the new direct
inner backedge observed 6 inner iterations, 2 outer iterations and final
`CNTR=0`; the established eleven native fixture regressions remain intact.
This proves local static P-code/C consistency and a bounded synthetic
runtime case, not complete hardware PC/LOOP stack equivalence. `PM:041E` still does not gain its two nested C loops under
the same direct-inner setting; this is an unresolved CFG/C contradiction and
must not be counted as recovered.

**DTS native return/CE frontier (local):** in an independently reopened
isolated DTS GZF, two previously `no-return`-marked routines `PM:06A9` and
`PM:06C1` contain native `RTS`. Restoring those return contracts and four
forced `CALL_RETURN` flow overrides exposed 175 DSP instructions in
`PM:03D7..048D`, including **12 additional native `DO UNTIL CE`** instructions
that were not counted in the previous decoded corpus. A separate provisional
RTS-bounded function at `PM:1364..1394` owns the `PM:1368` loop. DTS now has
**103/103** C-decompilable identified functions and **72/76** native CE ends
with conditional P-code after saved GZF reopen. The previous 63-CE DTS
inventory is superseded by this expanded 76-CE corpus, not a reduction of
remaining native loops. `ghidra_scripts/SunplusDtsRestoredFlowAcceptance.java`
checks the saved caller/callee contracts, expanded native code and owned CE.
All 76 native CE ends now belong to identified functions; the additional
function `PM:06B5..06C0` was recovered from three native `CALL` sites
`PM:043C/0443/044A`, with verified terminal `RTS` and existing CE P-code.
Four CE ends remain unresolved in DTS, including two heavy functions whose
modified C-decompilation timed out and two paths that introduced unreachable
block warnings. No canonical Analysis migration or board-level execution proof.

**Acceptance separation:** this confirms static Ghidra P-code/C recovery,
not emulator execution equivalence for emulators without that library. `CALLOTHER` PM userops do not themselves
read/write backing PM or implement read-after-write aliasing; a verified
emulator/userop library is still required. The original GZF code bytes were
preserved and production Analysis and the canonical project were not changed.
Full processor acceptance additionally requires the native fixture suite,
full five-program GZF C/CFG regression and this userop execution contract.

## Validation boundary

The language source must compile with Ghidra's support/sleigh compiler during
the Docker build and CI. Runtime acceptance additionally requires importing a
small raw fixture or a preserved target DSP image using
SunplusSPHEAudioDSP:BE:16:default and checking the known regression words.

Do not use this module to infer Sunplus-specific DM width, DSP clock, PM/DM
capacity, coefficient precision, or peripheral mapping. Those remain target behavior-analysis
questions. Current vector-seeded reachable-code acceptance over the preserved target profiles is:

- AUX: 5451 / 5451 reached words decoded, 0 gaps;
- PCM: 7787 / 7787, 0 gaps;
- AC-3: 10339 / 10339, 0 gaps;
- DTS: 9651 / 9651, 0 gaps.

The traversal follows decoded fallthrough and direct-flow edges from the observed vector seeds and stops at unsupported words. It deliberately does not treat unrelated coefficient/data regions as executable coverage. The bounded linear corpus scanner remains available for decoder-development diagnostics, but its output must not be interpreted as a code-completeness percentage.

## srvdsp analysis contract

The canonical 1128-byte `srvdsp.bin` corpus is the decompiler-grade acceptance target for this language module. The recovered image is loaded at PM word address `0x1800`; its first 32 words are a vector table and the locally implemented code occupies `PM:0x1820..0x1894`.

Both Type-15 SR OR LSHIFT HI/LO immediate forms also split by encoded sign. Isolated Ghidra tests prove branch-free P-code and SR0/SR1 numeric results for positive/negative shifts. The read-only canonical PCM GZF decompiler audit shows warning counts reduced from 43/91/256 to 0/0/0 in the three repeated table-builders (PM:0ED7, PM:0FFC, PM:167F), and 22 to 2 in GM5 PM:12A3. This validates improved generated C, not hardware semantics or the exact contents of the 24-bit PM stores.

Type-12 ASHIFT with register-controlled SE continues to use the dynamic
sign test by default. At a strictly proven negative-SE native site, the
optional codec_se_proven_negative context bit selects a branch-free arithmetic
right shift by the dynamic magnitude -SE, retaining parallel DM access and
DAG index updates. This was proven only for PCM PM:06C1 (SE=-1), PM:12BB
and PM:12BC (SE=-2) through native provenance plus isolated Ghidra C/IR and
15 differential EmulatorHelper cases. On the canonical PCM GZF copy the two
affected functions have 0 and 0 unreachable C warnings, without losing any
of GM5's eight loops. Source installation does not automatically mark these
three instructions in already persisted Ghidra projects: separately re-decode
each proven site inside a validated transaction and save/read back. Do not
enable this mode for arbitrary SE values or for unproven control-flow inputs.

Type-15 immediate ASHIFT and LSHIFT constructors are explicitly specialized
on the encoded count sign bit, rather than branching at runtime on an
immediate value known at decode time. This avoids spurious Ghidra
Removing unreachable block diagnostics for constant shift direction. A
read-only test against the canonical PCM GZF identified and eliminated the
PM:0859 warning; in combination with a statically selected two-level CE
model, resident handoff C contains four visible loops and zero such
warnings. This is isolated static/decompiler validation, not proof of
hardware PCM numeric equivalence or deployment.

Important Ghidra modeling details:

- PM uses `wordsize=3` and therefore **must use `alignment=3`**. `alignment=1` compiles but Ghidra 12.1.3 will not create instructions for the 24-bit stream.
- Java address APIs operate in byte offsets. Target DSP word addresses must be converted through `AddressSpace.getAddressableUnitSize()` before rebase, disassembly, or function creation.
- The compiler spec exposes a synthetic `SP` in DM solely to satisfy Ghidra stack/decompiler ABI requirements. This does not assert a physical software stack on the DSP; architectural return behavior remains represented by `PCSTACKTOP`.
- Jumps from the wrapper into resident PM outside the image are represented by `dsp_resident_tailcall` userops only when the canonical postprocessor/script sets `srvdsp_wrapper_mode=1`. Generic programs default to normal local jump semantics even if their numeric target matches a wrapper-resident address.
- The canonical `DO PM:186C UNTIL CE` sequence remains the wrapper-specific real `CNTR`-controlled flow. In codec mode, `DO ... UNTIL CE` now marks the decoded end instruction and emits a P-code counter decrement and conditional back-edge after its original P-code. An isolated PCM-native regression validates a single loop at PM:12B9..12BD. Codec counter loads through `LDI CNTR` and direct `DMREAD CNTR` now preserve an outer active counter in synthetic stack state, while `DO` saves the loop start separately. Isolated Ghidra emulator regressions execute two nested levels (2×3), four levels (2×3×2×2), and the native PCM direct-DM counter-load encoding. The lightweight non-nested P-code path remains the default (`codec_ce_nested_mode=0`). Only set `codec_ce_nested_mode=1` across verified overlapping native `DO` regions, before disassembling the relevant instructions; that selects the bounded stack model without regressing simple-loop C output. Existing saved instructions cannot accept context changes in place: clear only proven affected instructions in a controlled transaction and re-disassemble them. The models bound nesting at four and intentionally do not assert exact hardware overflow/status-stack handling, dynamic branches out of loops, arbitrary counter writers, or full-profile C/CFG correctness. The opted-in codec nested mode includes a bounded four-frame synthetic CALL/RTS return stack. It covers the conditional CALL and RTS forms used by this instruction corpus. Independent emulator tests validate unseeded return addresses for a single called inner CE loop, a two-stage native CALL chain, and the taken/skipped IF NE CALL branches. Real ADSP-218x hardware uses a shared 16-deep PC stack for both CALL and DO; separate synthetic call and loop slots do NOT reproduce shared overflow, interrupts, special stack instructions, or all non-local exits. When re-decoding a saved program, select nested mode only for validated DO, CNTR writes, CE ends, CALL sites and callee RTS (including conditional forms); leaving callee returns in default mode would invalidate the cross-call contract. The resident PCM handoff outer loop at PM:0833..0853 calls other DSP routines that also write CNTR; the synthetic nested acceptance does NOT prove preserving an outer count across interprocedural calls. Do not automatically enable nested mode over the whole PCM handoff until callee entry/exit and counter-stack interactions are checked. Existing saved analyses must re-disassemble affected loop instructions after installing the new language; decoder deployment alone does not update old P-code.
- Canonical `srvdsp.bin` analysis also materializes an uninitialized `SRVDSP_DM_STATE` block covering `DM:0000..017F.1`, so DSP state can be named and typed without altering PM bytes.
- Vector-seeded action nodes default to `void` return type unless a user-defined signature already exists, preventing generic undefined-return warnings in the behavior layer.
- Saved canonical programs carry a small analysis-model revision marker. Revision 3 applies wrapper context and refreshes only the known resident-handoff / CE-loop instruction words, so older saved state picks up context-scoped decoding without clearing the entire local code region or user action names/comments.

Acceptance requires the canonical corpus to produce zero undefined words in the 117-word local code region, seed all nine vector handlers as functions, successfully generate decompiler output for all nine functions, and expose the `PM:186C` CE loop as real control flow rather than an opaque userop.

## Upstream contribution handoff

The reusable processor support should eventually be separated from MCP/project-specific automation and contributed to Ghidra proper.

Tracking task: `ArthurKoba/hd-audio-rush-sphe8202r#30`.

Upstream extraction should preserve the processor language/compiler-spec semantics and architecture-level regression coverage, while excluding project-specific auto-import/rebase hooks, canonical action names/comments, saved-project revision hooks, and target firmware blobs unless their provenance/licensing is explicitly approved.

The preferred upstream test strategy is synthetic instruction/regression fixtures covering:

- big-endian 24-bit token mapping;
- PM addressable-unit behavior;
- DM/IO access;
- direct/conditional flow, including a generic target that numerically collides with a wrapper-resident handoff;
- arithmetic/condition behavior used by the recovered corpus;
- RTS versus RTI distinction and explicit RTI status-restoration side effect;
- the proven CE-loop counter/back-edge semantics under wrapper context.

An independent reviewer pass is required before treating the implementation as upstream-ready.



### Static CE edges after resident calls (scoped opt-in)

For individually proved native codec DO/end pairs, `codec_ce_direct_backedge=1`
and `codec_ce_direct_start` record the actual **backedge PM word address** in
Ghidra's *analysis-only* decode context. This emits a direct CFG edge instead
of depending on a synthetic loop-start register that the decompiler may treat
as clobbered by an intervening DSP `CALL`.

The 54-byte sequential-CE fixture exercises two consecutive loops (one
contains a native `CALL`) and requires **two actual C `do` loops**, not a
combined count of the `do` and `while` keywords. This is a Ghidra C/CFG
acceptance contract; it does not prove hardware cycle timing.

Do not enable the direct-backedge mode globally or infer a target from
instruction order. Confirm each target in the native `DO` and set the
context before decoding its CE end. For previously analyzed programs, use a
scoped transaction to clear and re-disassemble only the verified instructions;
preserve functions, comments, bytes and non-synthetic references. An existing
saved program does not automatically acquire new P-code after SLEIGH changes.


## Local DTS strict C/CE checkpoint — 2026-10-14

This checkpoint is a saved, independently reopened **isolated Ghidra GZF**.
It is not a deployment to production Analysis or silicon-equivalent emulation.
The final target has 103/103 decompiled functions, 76/76 native DO/CE ends
with identifiable external P-code branches, 0 semantic warnings and 0
global-symbol-overlap warnings under strict Ghidra corpus acceptance.
Initialized native source bytes, function identity/bounds and existing
automatically generated DM labels are unchanged. The CE count is an
external-branch-shape metric, not proof of all loop-stack or device timing.

The native Ghidra 12.1.3 decompiler's Funcdata::mapGlobals was instrumented:
625 conflict events in 91 DTS functions all required 2-byte DM words while
existing default DAT_DM symbols had a 1-byte size. There were 317 unique
native-referenced DM word addresses in 76 exactly contiguous runs.
The guarded, one-time, isolated
ghidra_scripts/SunplusDtsDmWordWidthRestore.java migration consumes
tests/fixtures/sunplus_sphe_audio_dsp/dts_dm16_evidence_20261014.txt
and validates the manifest checksum, 103-function inventory, 16-bit DM
address units, PM source byte hash, existing default symbol names, function
bodies and representative C loops. It creates only uninitialized 2-byte
DM words with an undefined2 data type; the original DAT_DM names remain.
It does not assert physical RAM, MMIO identity or external side effects.
Never run it on a canonical project with a different saved inventory.

The revised SLEIGH also includes opt-in nonnegative-SE shift forms and exact
zero-product MX0 * 0 with parallel DM reads/writes. The isolated DTS GZF
explicitly re-decodes individual native-proven shift, CE and nested counter
instructions. It also models DM:3C14 as volatile in a scoped analysis
snapshot. Merely deploying the new language cannot rewrite saved P-code
in an existing Ghidra project.

The separate Ghidra 12.1.3 native decompiler candidate patch is
patches/ghidra-12.1.3/native-word-addressed-ptradd-guard.patch.
It prevents ptrarith/ptraddundo oscillation when a 4-byte inferred element
cannot be represented by an integral number of 3-byte PM addressable units.
This is an out-of-tree change awaiting independent review; storing its patch
does not install it in the runtime server decompiler.

The five ORIGINAL, older DSP GZF corpus snapshots generate C for 322/322
functions with the final local SDK. This is a non-strict compatibility
regression only: the old snapshots still have missing per-instruction
context/data types and pre-existing semantic warnings. DTS strict local
acceptance neither closes those profiles nor proves full hardware audio
equivalence. Production rollout and canonical Analysis migration require
independent review and separately authorized deployment, guarded analysis
updates, save and independent readback.

Architecture-derived preparation passes and explicit safety/assembler limits:
see docs/project-management/SUNPLUS_DSP_ARCHITECTURE_RECOVERY.md.

## RUSH 28 — automatic native CE recovery, integration gate (2026-10-24)

The architecture-level analyzer is implemented at
`src/main/java/com/xebyte/sunplus/SunplusNativeCeAutoAnalyzer.java` and is
registered with Ghidra as **Sunplus DSP Native DO/CE Flow**. It discovers
source-encoded 24-bit `DO ... UNTIL CE` endpoints, verifies a bounded upstream
CNTR writer, rejects overlapping/nested loop intervals, checks native direct
flow and leaf callees, and can recode proven CE endpoints while regenerating
Analyzer C for affected existing functions. No addresses, program names, or
firmware hashes are built into this rule. The resident wrapper has a separate
context contract.

**Release gate:** The analyzer is **discoverable but disabled by default**.
Ghidra MCP scripts can own an outer transaction; ending a nested transaction
with `commit=false` does not necessarily restore in-memory program state.
Thus automatic mutation must not be enabled for fresh imports until a
throwaway source-backed import validates failure rollback and saved/read-back
behavior in the actual Analyzer lifecycle. `dryRun` is strictly read-only,
not a speculative write-and-rollback. A failure of the native C gate must not
silently alter a user's program. The opt-in processor software-stack view
remains separately executable and does not imply silicon/runtime proof.

Local integration: the new analyzer was discovered by Ghidra on all five saved
modules, built with the installed Ghidra 12.1.3 SDK. A single broad
read-only MCP job visited all five original saved program images without
changing firmware bytes, function ownership, or native CE metadata. Generic
source-eligible work was identified in PCM (16 loops, 8 owners) and AUX
(2 loops, 2 owners); DTS and AC-3 had no newly eligible basic loops after
previous saved recovery. The accepted saved native C corpus remains
510/510, with 0 warnings, and the normalized Pcode corpus is
29,214/29,214 with 0 discrepancies. These are **known-function and
already-decoded instruction scopes**, not complete ISA/semantic coverage.

Next release gates are: an isolated source-backed fresh import; one batch
processor auto-analysis pass; compare exact machine-byte identity and new
Analyzer C/Pcode with the independently accepted corpus; validate negative
cases (nested unknowns, computed flow, callee CNTR side effects, and failed
C generation); save/close/reopen readback; then explicitly enable automatic
recovery and move to the canonical Analyzer project. Existing independent
Java checks become regression tools, not a series of mandatory manual repairs.

### Fresh-import ABI acceptance (RUSH 28)

A clean, source-identical `srvdsp.bin` fixture was imported through the **actual
Analyzer MCP `/import_file` endpoint with `auto_analyze=true`**, into a
temporary folder within the existing saved local Ghidra project. The native
import/postprocessor recovered base `PM:1800` and all **9 original executable
handlers**. Before the fix, Analyzer C generated for all nine but every
function carried `Unknown calling convention -- yet parameter storage is
locked`: freshly created handlers used calling convention `unknown`, while
the compiler specification and previously accepted program used `default`.

`SunplusSrvdspPostProcessor.prepare()` now assigns the compiler spec's
native default convention only to analysis-owned functions with `unknown`
convention, **before** setting the `void` return type. It does not touch
`USER_DEFINED` signatures. A second independently imported copy of the
identical 1,128-byte executable image generated **9/9 non-empty Analyzer C
functions with zero warning lines** and **149/149 normalized native P-code
instructions matching the currently installed SLEIGH decoder**. This is a
real fresh-import regression test, not replayed/synthetic C.

The two QA program copies were explicitly deleted after validation and the
five original DSP programs were read back in the single local Ghidra project.
The raw source, generated independent C/P-code reports, backup extension jar,
and monitored-job logs remain as test artifacts. The generic `DO/CE`
auto-analyzer stays *disabled by default* until automatic C-failure rollback
and fresh native codec-profile import (beyond the resident fixture) pass.
Hardware equivalence is not claimed.
