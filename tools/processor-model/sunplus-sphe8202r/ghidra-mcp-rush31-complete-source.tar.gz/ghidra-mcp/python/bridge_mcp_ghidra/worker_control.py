"""Worker-slot maintenance and recovery controls for the headless project router."""

from __future__ import annotations

import asyncio
import os
import stat
import time
from pathlib import Path
from typing import Any

from . import operation_queue, project_sessions, state, transport


def _slot(worker_index: int) -> project_sessions.WorkerSlot:
    with project_sessions._lock:
        project_sessions._sync_worker_config_locked()
        slots = list(project_sessions._slots.values())
        if worker_index < 0 or worker_index >= len(slots):
            raise project_sessions.ProjectSessionError(
                f"Unknown worker_index {worker_index}; configured workers: {len(slots)}"
            )
        return slots[worker_index]


def set_worker_enabled(
    worker_index: int,
    enabled: bool,
    close_project: bool = True,
) -> dict[str, Any]:
    """Enable or disable one worker slot for project routing.

    Disabling does not kill the JVM. It removes the worker from routing and,
    when idle, optionally closes its active project session first.
    """

    with project_sessions._lock:
        slot = _slot(worker_index)

        if enabled:
            if _worker_pid_file(worker_index).with_suffix(".stopped").exists():
                raise project_sessions.ProjectSessionError(
                    f"Worker {worker_index} is physically stopped; call start_worker"
                )
            slot.enabled = True
            return {
                **project_sessions._slot_status(worker_index, slot),
                "changed": True,
            }

        if slot.in_flight or slot.queued or slot.running:
            raise project_sessions.ProjectBusyError(
                f"Worker {worker_index} is busy: "
                f"in_flight={slot.in_flight}, queued={slot.queued}, running={slot.running}"
            )

        if close_project and (slot.project_id or slot.project_name):
            project_sessions._request(
                slot.url,
                "POST",
                "/close_project",
                json_data={"dry_run": False},
                timeout=30,
            )
            slot.project_id = None
            slot.project_name = None
            slot.current_operation = None
            slot.last_used_at = 0.0

        slot.enabled = False
        return {
            **project_sessions._slot_status(worker_index, slot),
            "changed": True,
        }


async def clear_worker_queue(worker_index: int) -> dict[str, Any]:
    """Cancel bridge requests waiting behind the current operation on one worker."""

    slot = await state.run_in_worker(_slot, worker_index)
    cancelled = await operation_queue.cancel(
        slot.url,
        include_running=False,
    )
    with project_sessions._lock:
        current = project_sessions._slots[slot.url]
        return {
            **project_sessions._slot_status(worker_index, current),
            **cancelled,
        }


def _prepare_recovery(worker_index: int) -> tuple[str, bool, str | None, str | None]:
    with project_sessions._lock:
        slot = _slot(worker_index)
        previous_enabled = slot.enabled
        project_id = slot.project_id
        project_name = slot.project_name
        slot.enabled = False
        slot.error = "recovering"
        return slot.url, previous_enabled, project_id, project_name


def _reset_slot_after_cancel(worker_url: str) -> None:
    with project_sessions._lock:
        slot = project_sessions._slots[worker_url]
        slot.in_flight = 0
        slot.queued = 0
        slot.running = 0
        slot.current_operation = None
        slot.project_id = None
        slot.project_name = None
        slot.last_used_at = 0.0
        operation_queue.reset_worker(worker_url)


def _worker_control_fifo() -> Path:
    return Path(
        os.getenv(
            "GHIDRA_MCP_WORKER_CONTROL_FIFO",
            "/data/bridge/worker-control.fifo",
        )
    )


def _worker_pid_file(worker_index: int) -> Path:
    root = Path(
        os.getenv(
            "GHIDRA_MCP_WORKER_PID_DIR",
            "/data/bridge/workers",
        )
    )
    return root / f"worker-{worker_index}.pid"


def _read_worker_pid(worker_index: int) -> int | None:
    try:
        raw = _worker_pid_file(worker_index).read_text(encoding="utf-8").strip()
    except OSError:
        return None
    if not raw.isdigit():
        return None
    return int(raw)


def _request_worker_restart(worker_index: int, worker_url: str) -> tuple[str, int | None]:
    fifo = _worker_control_fifo()
    previous_pid = _read_worker_pid(worker_index)
    try:
        mode = fifo.stat().st_mode
    except OSError:
        mode = 0
    if stat.S_ISFIFO(mode):
        fd = os.open(fifo, os.O_WRONLY | os.O_NONBLOCK)
        try:
            os.write(fd, f"restart {worker_index}\n".encode("ascii"))
        finally:
            os.close(fd)
        return "supervisor-sigkill", previous_pid

    # Non-Docker/manual fallback where no shared supervisor control FIFO exists.
    project_sessions._request(
        worker_url,
        "POST",
        "/exit_ghidra",
        timeout=1,
    )
    return "native-exit", previous_pid


def worker_heap_settings(worker_index: int) -> dict[str, Any]:
    """Read persisted per-worker heap override, without asserting active JVM RSS."""
    slot = _slot(worker_index)
    heap_file = _worker_pid_file(worker_index).with_suffix(".heap-mb")
    try:
        raw = heap_file.read_text(encoding="utf-8").strip()
        value = int(raw) if raw.isdecimal() else None
    except OSError:
        value = None
    return {
        "worker_index": worker_index,
        "worker_url": slot.url,
        "configured_max_heap_mb": value,
        "override_present": value is not None,
        "note": "This is a saved -Xmx override, not measured JVM RSS/cgroup usage.",
    }


def set_worker_max_heap_mb(worker_index: int, max_heap_mb: int) -> dict[str, Any]:
    """Persist a JVM heap ceiling through the owning supervisor."""
    if type(max_heap_mb) is not int or not 128 <= max_heap_mb <= 32768:
        raise project_sessions.ProjectSessionError("max_heap_mb must be 128..32768")
    slot = _slot(worker_index)
    fifo = _worker_control_fifo()
    try:
        if not stat.S_ISFIFO(fifo.stat().st_mode):
            raise project_sessions.ProjectSessionError("Worker supervisor FIFO unavailable")
        fd = os.open(fifo, os.O_WRONLY | os.O_NONBLOCK)
        try:
            os.write(fd, f"heap {worker_index} {max_heap_mb}\n".encode("ascii"))
        finally:
            os.close(fd)
    except OSError as exc:
        raise project_sessions.ProjectSessionError("Worker supervisor unavailable") from exc
    # A FIFO write only queues work. Verify that the supervisor persisted
    # the desired value before reporting successful configuration.
    heap_file = _worker_pid_file(worker_index).with_suffix(".heap-mb")
    deadline = time.monotonic() + 2.0
    persisted = False
    while time.monotonic() < deadline:
        try:
            persisted = heap_file.read_text(encoding="utf-8").strip() == str(max_heap_mb)
        except OSError:
            persisted = False
        if persisted:
            break
        time.sleep(0.05)
    if not persisted:
        raise project_sessions.ProjectSessionError(
            f"Supervisor did not confirm the heap override for worker {worker_index}"
        )
    return {
        "worker_index": worker_index,
        "worker_url": slot.url,
        "configured_max_heap_mb": max_heap_mb,
        "persisted": True,
        "restart_requested": True,
        "note": "Saved -Xmx override; active JVM startup and physical RSS remain separately unverified.",
    }


def _send_supervisor_command(worker_index: int, action: str) -> None:
    _slot(worker_index)
    fifo = _worker_control_fifo()
    if action not in {"stop", "start"}:
        raise ValueError("Unsupported supervisor action")
    try:
        if not stat.S_ISFIFO(fifo.stat().st_mode):
            raise project_sessions.ProjectSessionError("Worker supervisor FIFO unavailable")
        fd = os.open(fifo, os.O_WRONLY | os.O_NONBLOCK)
        try:
            os.write(fd, f"{action} {worker_index}\n".encode("ascii"))
        finally:
            os.close(fd)
    except OSError as exc:
        raise project_sessions.ProjectSessionError("Worker supervisor unavailable") from exc


async def hard_stop_worker(worker_index: int, timeout_seconds: float = 4.0) -> dict[str, Any]:
    """Disable routing, SIGKILL the selected JVM and wait for supervisor reaping."""
    worker_url, previous_enabled, previous_project_id, previous_project_name = await state.run_in_worker(
        _prepare_recovery, worker_index
    )
    previous_pid = await state.run_in_worker(_read_worker_pid, worker_index)
    try:
        await state.run_in_worker(_send_supervisor_command, worker_index, "stop")
    except (project_sessions.ProjectSessionError, OSError):
        await state.run_in_worker(
            _finish_recovery, worker_index, worker_url, previous_enabled
        )
        raise
    try:
        cancelled = await asyncio.wait_for(
            operation_queue.cancel(worker_url, include_running=True), timeout=1.0
        )
    except TimeoutError:
        cancelled = {"cancellation_pending": True}
    await state.run_in_worker(_reset_slot_after_cancel, worker_url)
    deadline = time.monotonic() + min(10.0, max(1.0, float(timeout_seconds)))
    while time.monotonic() < deadline:
        pid = await state.run_in_worker(_read_worker_pid, worker_index)
        if pid is None:
            with project_sessions._lock:
                slot = project_sessions._slots[worker_url]
                slot.enabled = False
                slot.error = "stopped"
            return {
                "worker_index": worker_index,
                "stopped": True,
                "previous_pid": previous_pid,
                "previous_project_id": previous_project_id,
                "previous_project_name": previous_project_name,
                **cancelled,
            }
        await asyncio.sleep(0.05)
    with project_sessions._lock:
        project_sessions._slots[worker_url].error = "stop unconfirmed"
    raise project_sessions.ProjectSessionError(
        f"Worker {worker_index} did not confirm SIGKILL/reap within the timeout"
    )


async def start_worker(worker_index: int, timeout_seconds: float = 10.0) -> dict[str, Any]:
    """Re-enable the selected supervisor-managed JVM and prove it is healthy."""
    slot = await state.run_in_worker(_slot, worker_index)
    with project_sessions._lock:
        previous_enabled, previous_error = slot.enabled, slot.error
        slot.enabled = False
        slot.error = "starting"
    try:
        await state.run_in_worker(_send_supervisor_command, worker_index, "start")
    except (project_sessions.ProjectSessionError, OSError):
        with project_sessions._lock:
            slot.enabled, slot.error = previous_enabled, previous_error
        raise
    deadline = time.monotonic() + min(30.0, max(1.0, float(timeout_seconds)))
    while time.monotonic() < deadline:
        pid = await state.run_in_worker(_read_worker_pid, worker_index)
        healthy = pid is not None and await state.run_in_worker(_worker_healthy, slot.url)
        if healthy:
            with project_sessions._lock:
                slot.enabled = True
                slot.error = None
            return {"worker_index": worker_index, "started": True, "pid": pid}
        await asyncio.sleep(0.1)
    with project_sessions._lock:
        slot.error = "start unconfirmed"
    raise project_sessions.ProjectSessionError(
        f"Worker {worker_index} did not become healthy within the timeout"
    )


def _worker_healthy(worker_url: str) -> bool:
    try:
        text, status = transport.do_request(
            "GET",
            "/check_connection",
            timeout=2,
            connection=project_sessions._snapshot(worker_url),
        )
    except Exception:
        return False
    return status == 200 and bool(text.strip())


def _finish_recovery(worker_index: int, worker_url: str, enabled: bool) -> dict[str, Any]:
    with project_sessions._lock:
        slot = project_sessions._slots[worker_url]
        slot.enabled = enabled
        slot.error = None
        return project_sessions._slot_status(worker_index, slot)


async def recover_worker(
    worker_index: int,
    *,
    timeout_seconds: float = 4.0,
) -> dict[str, Any]:
    """Hard-restart exactly one worker and restore it within a bounded fast path."""

    budget = min(4.0, max(1.0, float(timeout_seconds)))
    started = time.monotonic()
    worker_url, previous_enabled, project_id, project_name = await state.run_in_worker(
        _prepare_recovery,
        worker_index,
    )
    cancelled = await operation_queue.cancel(
        worker_url,
        include_running=True,
    )
    await state.run_in_worker(_reset_slot_after_cancel, worker_url)

    restart_method, previous_pid = await state.run_in_worker(
        _request_worker_restart,
        worker_index,
        worker_url,
    )

    # Supervisor-managed Docker recovery is identified by PID generation, not
    # a fleeting closed-port window that can be missed during a very fast restart.
    observed_down = False
    observed_new_pid = restart_method != "supervisor-sigkill"
    deadline = started + budget
    while time.monotonic() < deadline:
        if restart_method == "supervisor-sigkill" and not observed_new_pid:
            current_pid = await state.run_in_worker(_read_worker_pid, worker_index)
            observed_new_pid = current_pid is not None and previous_pid is not None and current_pid != previous_pid
        healthy = await state.run_in_worker(_worker_healthy, worker_url)
        if restart_method != "supervisor-sigkill" and not healthy:
            observed_down = True
        generation_changed = observed_new_pid or observed_down
        if healthy and generation_changed:
            status = await state.run_in_worker(
                _finish_recovery,
                worker_index,
                worker_url,
                previous_enabled,
            )
            return {
                **status,
                **cancelled,
                "recovered": True,
                "restart_method": restart_method,
                "recovery_ms": round((time.monotonic() - started) * 1000, 1),
                "previous_project_id": project_id,
                "previous_project_name": project_name,
            }
        await asyncio.sleep(0.05)

    with project_sessions._lock:
        slot = project_sessions._slots[worker_url]
        slot.error = f"worker recovery exceeded {budget:.1f}s budget"
    raise project_sessions.ProjectSessionError(f"Worker {worker_index} did not recover within {budget:.1f}s")
