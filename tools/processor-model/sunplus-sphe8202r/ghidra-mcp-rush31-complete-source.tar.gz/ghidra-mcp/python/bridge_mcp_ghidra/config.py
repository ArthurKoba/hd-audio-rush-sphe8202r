"""Configuration constants, timeouts, environment, and logging for the bridge."""

import logging
import os

# ==========================================================================
# Request timeouts
# ==========================================================================

# Per-endpoint timeout overrides for expensive operations
ENDPOINT_TIMEOUTS = {
    "rename_variables": 120,
    "batch_rename_variables": 120,
    "batch_set_comments": 120,
    "analyze_function_complete": 120,
    "batch_rename_function_components": 120,
    "set_variables": 90,
    "analyze_data_region": 90,
    "create_label": 60,
    "delete_label": 60,
    "disassemble_bytes": 120,
    "bulk_fuzzy_match": 180,
    "find_similar_functions_fuzzy": 60,
    "import_file": 300,
    "run_ghidra_script": 1800,
    "run_script_inline": 1800,
    # Ghidra's default decompile cap is 60s. The bridge must outlive it so the
    # plugin can return a structured timeout instead of writing into a closed
    # socket after the client has already gone away.
    "decompile_function": 75,
    "set_function_prototype": 45,
    "rename_function": 45,
    "consolidate_duplicate_types": 60,
    "analyze_function_completeness": 120,
    "apply_function_documentation": 60,
    # get_timeout() keys on the LAST path segment, so "/debugger/launch"
    # looks up "launch" here, not "debugger_launch" -- easy to miss when
    # adding overrides for nested debugger/* routes.
    "launch": 120,
    "default": 30,
}

REQUEST_TIMEOUT_GRACE_SECONDS = 15
# Long-running endpoints may legitimately ask Ghidra to spend 1800 seconds on
# work (for example run_script_inline/run_ghidra_script or a user-raised
# decompile timeout). Keep the transport alive slightly longer so the bridge can
# receive and forward Ghidra's final status instead of closing first.
MAX_REQUEST_TIMEOUT_SECONDS = 1815

try:
    MAX_CONCURRENT_GHIDRA_REQUESTS = max(1, int(os.getenv("GHIDRA_MCP_MAX_CONCURRENT_REQUESTS", "4")))
except ValueError:
    MAX_CONCURRENT_GHIDRA_REQUESTS = 4

DEFAULT_TCP_URL = "http://127.0.0.1:8089"
DEFAULT_TCP_PORT = 8089
# When set, forwarded to the Ghidra server as `Authorization: Bearer <token>`.
# Same env var the plugin/headless server enforces (v5.4.1+); unset = no header.
AUTH_TOKEN = (os.getenv("GHIDRA_MCP_AUTH_TOKEN") or "").strip()
# Bridge-side TCP port scan range. Mirrors the plugin's
# TCP_PORT_FALLBACK_RANGE so a TCP-only multi-instance setup (e.g. Windows
# 10 pre-1803 where AF_UNIX is unavailable) can still be discovered without
# having to set GHIDRA_MCP_URL per instance. See issue #175 + Copilot review.
TCP_PORT_SCAN_RANGE = 16

# Debugger proxy target (the debugger server, which lives in the d2-game-exe
# repo since 2026-08-11). Empty/default points at the
# standalone debugger server's default port.
DEBUGGER_URL = os.getenv("GHIDRA_DEBUGGER_URL", "http://127.0.0.1:8099")

# D2Debugger in-process oracle (D2MOO's D2Debugger.dll, compiled into the running
# Game.exe and serving 127.0.0.1:8790). Unlike DEBUGGER_URL this is not a debugger
# at all -- it is an HTTP surface *inside* the live game, so it answers while the
# game runs and needs no elevation on the client side (loopback TCP is not gated
# by integrity level). Env name matches the one fun-doc/D2MOO tooling already uses.
ORACLE_URL = os.getenv("D2DBG_MCP_URL", "http://127.0.0.1:8790")

# ==========================================================================
# Logging
# ==========================================================================

LOG_LEVEL = os.getenv("GHIDRA_MCP_LOG_LEVEL", "INFO")
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("bridge_mcp_ghidra")

# ==========================================================================
# Tool-group / static-tool catalog constants
# ==========================================================================

MANAGEMENT_TOOL_NAMES = {
    "list_instances",
    "connect_instance",
    "list_projects",
    "open_project",
    "close_project",
    "create_project",
    "delete_project",
    "project_session_info",
    "release_project_session",
    "set_project_idle_timeout",
    "project_session_settings",
    "set_worker_enabled",
    "clear_worker_queue",
    "recover_worker",
    "set_worker_max_heap_mb",
    "worker_heap_settings",
    "hard_stop_worker",
    "start_worker",
    "list_tool_groups",
    "load_tool_group",
    "unload_tool_group",
    "check_tools",
    "search_tools",
    "import_file",
}

# WinDbg debugger proxy tools (Phase 1+2+3). The standalone debugger server
# (in the d2-game-exe repo) wraps dbgeng via pybag and only runs on Windows, so these
# are registered conditionally — see debugger._debugger_enabled(). The names stay
# reserved in _ALL_STATIC_TOOL_NAMES on every platform so dynamic-tool naming is
# identical everywhere (a Ghidra /debugger/status endpoint -> debugger_status_2
# regardless of whether our proxy is active on this host).
DEBUGGER_TOOL_NAMES = {
    "debugger_attach",
    "debugger_detach",
    "debugger_status",
    "debugger_modules",
    "debugger_resolve_ordinal",
    "debugger_set_breakpoint",
    "debugger_remove_breakpoint",
    "debugger_list_breakpoints",
    "debugger_continue",
    "debugger_step_into",
    "debugger_step_over",
    "debugger_registers",
    "debugger_read_memory",
    "debugger_stack_trace",
    "debugger_read_args",
    "debugger_trace_function",
    "debugger_trace_stop",
    "debugger_trace_log",
    "debugger_trace_list",
    "debugger_watch_memory",
    "debugger_watch_stop",
    "debugger_watch_log",
}

# D2Debugger in-process oracle proxy tools. Registered conditionally (see
# oracle._oracle_enabled()) for the same reason as the debugger names: reserved
# in _ALL_STATIC_TOOL_NAMES on every platform so dynamic-tool naming stays
# identical everywhere, but only registered where the oracle can actually exist.
ORACLE_TOOL_NAMES = {
    "oracle_status",
    "oracle_modules",
    "oracle_read_memory",
    "oracle_call_function",
    "oracle_prove_function",
}

# Full structural set: every tool name the bridge may define. Used for
# name-collision detection / reservation so dynamic tool names are platform-stable.
_ALL_STATIC_TOOL_NAMES = MANAGEMENT_TOOL_NAMES | DEBUGGER_TOOL_NAMES | ORACLE_TOOL_NAMES

# Active set: static tools actually registered with this process. Debugger names
# are added by bridge_mcp_ghidra.debugger (once DEBUGGER_URL is known) only when
# the debugger backend is usable on this host. Used for runtime availability
# reporting (check_tools etc.). Mutated in place (|=), never rebound, so modules
# that imported this name earlier still see the update.
STATIC_TOOL_NAMES = set(MANAGEMENT_TOOL_NAMES)

# Core groups always loaded on connect (essential for basic RE workflow)
CORE_GROUPS = {"listing", "function", "program"}
